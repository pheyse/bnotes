package de.brightside.bnotes.bnotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BnotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BnotesApplication.class, args);
	}

}
