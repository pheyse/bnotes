package de.brightside.bnotes.bnotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BnotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
